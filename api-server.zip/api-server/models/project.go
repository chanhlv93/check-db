package models

type Project struct {
	Id                   int       `sql:"AUTO_INCREMENT",json:"id"`
	OrgId                int       `json:"orgId"`
	Name                 string    `json:"name"`
	Description          string    `json:"description"`
	Image                string    `json:"image"`
	Params 		     string    `json:"params,omitempty"`
}